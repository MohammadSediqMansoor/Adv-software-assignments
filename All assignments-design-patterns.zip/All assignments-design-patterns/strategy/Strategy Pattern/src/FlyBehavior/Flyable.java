package FlyBehavior;

public interface Flyable {
    public void fly();
}
