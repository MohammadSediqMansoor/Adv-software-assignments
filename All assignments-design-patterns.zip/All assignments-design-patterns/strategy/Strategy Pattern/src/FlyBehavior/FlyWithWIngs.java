package FlyBehavior;

public class FlyWithWIngs implements Flyable {

    @Override
    public void fly() {
        System.out.println("I can fly");
    }
    
}
