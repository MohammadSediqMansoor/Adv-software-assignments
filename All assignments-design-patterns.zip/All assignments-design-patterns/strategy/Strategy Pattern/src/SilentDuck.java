public class SilentDuck {

    public void display(){
        System.out.println("I am Silent Duck");
    }

    public void swim(){
        System.out.println("I can not swim");
    }
    
}
