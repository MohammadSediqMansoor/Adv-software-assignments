package QuackBehavior;

public class Squeack implements Quackable {

    @Override
    public void quack() {
        System.out.println("Squeak");
    }
    
}
