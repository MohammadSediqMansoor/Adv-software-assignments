package QuackBehavior;

public interface Quackable {
    public void quack();
}
