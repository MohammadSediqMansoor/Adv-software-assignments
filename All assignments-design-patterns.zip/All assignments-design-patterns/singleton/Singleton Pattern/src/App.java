public class App {
    public static void main(String[] args){
        LogIn obj = new LogIn();
        obj.getTheme();

        Dashboard obj2 = new Dashboard();
        obj2.getTheme();
    }
}
