public class Dashboard {

    public void getTheme(){
        Settings obj = Settings.getInstance();
        System.out.println(obj.theme);;
    }

}
