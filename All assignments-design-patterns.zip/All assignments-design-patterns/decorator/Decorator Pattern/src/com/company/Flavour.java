package com.company;

public abstract class Flavour extends Coffee {
    public abstract double cost();
}
