package com.company.CoffeeTypes;

import com.company.Coffee;

public class DarkCoffee extends Coffee {

    @Override
    public double cost() {
        return 3;
    }
    
}
