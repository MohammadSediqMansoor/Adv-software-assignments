package com.company.CoffeeTypes;

import com.company.Coffee;

public class Espreso extends Coffee {
    @Override
    public double cost() {
        return 1;
    }
}
