package com.company;

public abstract class Coffee {
    public void discription(){
        System.out.println("discription");
    }

    public abstract double cost();
}
